(() => {
  'use strict';

  const cfg = window.MASHAWER_CONFIG || {};
  const hasSupabase = Boolean(window.supabase && cfg.SUPABASE_URL && cfg.SUPABASE_ANON_KEY && cfg.SUPABASE_ANON_KEY.length > 30);
  const client = hasSupabase ? window.supabase.createClient(cfg.SUPABASE_URL, cfg.SUPABASE_ANON_KEY) : null;
  const app = document.getElementById('app');
  const toastNode = document.getElementById('toast');

  const categories = ['الكل', 'مطاعم', 'بقالة', 'صيدلية', 'طرود'];
  let merchants = [
    { id: 'm1', name: 'مطعم البيت الشامي', category: 'مطاعم', description: 'أكل بيتي وسندوتشات طازة', eta: '25 - 35 دقيقة', fee: 18, color: 'linear-gradient(135deg,#e76f39,#9e3b31)', symbol: '🍲' },
    { id: 'm2', name: 'سوبر ماركت البركة', category: 'بقالة', description: 'كل احتياجات البيت في مكان واحد', eta: '35 - 45 دقيقة', fee: 22, color: 'linear-gradient(135deg,#2d8a70,#1c5360)', symbol: '🛒' },
    { id: 'm3', name: 'صيدلية الحياة', category: 'صيدلية', description: 'طلبك الصحي يوصلك بأمان', eta: '20 - 30 دقيقة', fee: 15, color: 'linear-gradient(135deg,#3e8bc4,#3565a5)', symbol: '✚' }
  ];
  let products = [
    { id: 'p1', merchant_id: 'm1', name: 'وجبة مشاوي مشكلة', description: 'تكفي شخصين مع الأرز والسلطة', price: 185, emoji: '🍗', category: 'مطاعم' },
    { id: 'p2', merchant_id: 'm1', name: 'كشري مشاوير', description: 'خلطة البيت الحارة', price: 65, emoji: '🥘', category: 'مطاعم' },
    { id: 'p3', merchant_id: 'm1', name: 'ساندوتش شاورما', description: 'عيش طازج وصوص خاص', price: 75, emoji: '🌯', category: 'مطاعم' },
    { id: 'p4', merchant_id: 'm2', name: 'سلة خضار اليوم', description: 'اختيار طازج من السوق', price: 120, emoji: '🥬', category: 'بقالة' },
    { id: 'p5', merchant_id: 'm2', name: 'مياه معدنية', description: 'كرتونة 12 زجاجة', price: 95, emoji: '💧', category: 'بقالة' },
    { id: 'p6', merchant_id: 'm2', name: 'مستلزمات منزلية', description: 'منتجات يومية مختارة', price: 80, emoji: '🧺', category: 'بقالة' },
    { id: 'p7', merchant_id: 'm3', name: 'فيتامينات يومية', description: 'بعد مراجعة الوصفة عند الحاجة', price: 160, emoji: '💊', category: 'صيدلية' },
    { id: 'p8', merchant_id: 'm3', name: 'مستلزمات إسعاف', description: 'حقيبة صغيرة للبيت', price: 210, emoji: '🩹', category: 'صيدلية' }
  ];
  const demoOrders = [
    { id: 'MW-1042', merchant: 'مطعم البيت الشامي', customer: 'أحمد حسن', status: 'progress', statusText: 'مع المندوب', total: 238, address: 'شارع المدرسة القديمة', payment: 'دفعت للمحل', created_at: 'منذ 12 دقيقة' },
    { id: 'MW-1038', merchant: 'سوبر ماركت البركة', customer: 'سارة محمود', status: 'success', statusText: 'تم التسليم', total: 164, address: 'منطقة السوق', payment: 'Vodafone Cash', created_at: 'أمس' },
    { id: 'MW-1031', merchant: 'صيدلية الحياة', customer: 'محمود علي', status: 'new', statusText: 'جديد', total: 175, address: 'خلف الوحدة الصحية', payment: 'InstaPay', created_at: 'أمس' }
  ];
  const demoCouriers = [
    { name: 'ياسر محمد', phone: '010•••8421', status: 'نشط', approved: true, orders: 24, earnings: 1860 },
    { name: 'كريم السيد', phone: '011•••1904', status: 'بانتظار الموافقة', approved: false, orders: 0, earnings: 0 },
    { name: 'مصطفى عادل', phone: '012•••7338', status: 'غير متصل', approved: true, orders: 17, earnings: 1290 }
  ];

  const state = {
    user: null,
    profile: null,
    view: 'customer',
    authMode: 'login',
    authRole: 'customer',
    trackingOrder: null,
    trackingHistory: [],
    modal: null,
    selectedCategory: 'الكل',
    selectedMerchant: null,
    cart: [],
    orders: [...demoOrders],
    couriers: [...demoCouriers],
    notifications: [],
    liveChannel: null,
    courierOnline: true,
    adminTab: 'overview',
    location: null,
    busy: false,
    refreshTimer: null
  };

  const money = (value) => `${Number(value || 0).toLocaleString('ar-EG')} ج.م`;
  const escapeHTML = (value) => String(value ?? '').replace(/[&<>'"]/g, (char) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', "'": '&#039;', '"': '&quot;' }[char]));
  const initials = (value) => String(value || 'م').trim().split(/\s+/).slice(0, 2).map((word) => word[0]).join('') || 'م';
  const roleName = (role) => ({ admin: 'الإدارة', courier: 'المندوب', customer: 'المستخدم' }[role] || 'المستخدم');
  const loginRoles = ['customer', 'courier', 'admin'];
  const signupRoles = ['customer', 'courier'];
  const normalizePhone = (value) => {
    const digits = String(value || '').replace(/\D/g, '');
    if (digits.startsWith('20')) return `+${digits}`;
    if (digits.startsWith('0')) return `+20${digits.slice(1)}`;
    return `+${digits}`;
  };
  const authEmail = (phone) => `${normalizePhone(phone).replace('+', '')}@mashwer.local`;
  const authErrorMessage = (error) => {
    const message = String(error?.message || '').toLowerCase();
    if (message.includes('invalid login credentials')) return 'رقم الهاتف أو كلمة المرور غير صحيحة.';
    if (message.includes('email not confirmed')) return 'الحساب لم يتم تفعيله بعد. أعد إنشاء الحساب أو تواصل مع الإدارة.';
    if (message.includes('already registered') || message.includes('already been registered')) return 'هذا الرقم مسجل بالفعل. استخدم تسجيل الدخول.';
    if (message.includes('rate limit') || message.includes('email rate limit')) return 'تم تجاوز حد التسجيل مؤقتًا. انتظر قليلًا ثم حاول مرة أخرى.';
    if (message.includes('password') && message.includes('6')) return 'كلمة المرور يجب أن تكون 6 أحرف أو أرقام على الأقل.';
    return error?.message || 'حدث خطأ في المصادقة. حاول مرة أخرى.';
  };
  const currentRole = () => state.profile?.role || state.user?.user_metadata?.role || 'customer';
  const isDemo = () => Boolean(state.user?.demo);
  const productFor = (id) => products.find((product) => product.id === id);
  const merchantFor = (id) => merchants.find((merchant) => merchant.id === id);
  const selectedMerchant = () => state.selectedMerchant ? merchantFor(state.selectedMerchant) : null;
  const cartSubtotal = () => state.cart.reduce((sum, line) => sum + (line.price * line.quantity), 0);
  const cartFee = () => selectedMerchant()?.fee || 18;
  const cartTotal = () => cartSubtotal() + (state.cart.length ? cartFee() : 0);
  const orderLabels = {
    pending: 'جاري البحث عن مندوب', confirmed: 'تم تأكيد الطلب', searching_driver: 'جاري البحث عن مندوب', assigned: 'تم تعيين مندوب',
    driver_accepted: 'المندوب قبل الطلب', heading_to_pickup: 'في الطريق للاستلام', arrived_pickup: 'وصل للاستلام', picked_up: 'تم استلام الطلب',
    delivering: 'في الطريق إليك', arrived_destination: 'وصل للعنوان', delivered: 'تم التسليم', cancelled: 'ملغي', rejected: 'مرفوض', failed: 'تعذر التنفيذ'
  };
  const legacyStatuses = { 'جديد': 'pending', 'مقبول': 'driver_accepted', 'قيد التجهيز': 'heading_to_pickup', 'مع المندوب': 'delivering', 'تم التسليم': 'delivered', 'ملغي': 'cancelled' };
  const canonicalStatus = (order) => orderLabels[order?.status] ? order.status : (legacyStatuses[order?.statusText] || 'pending');

  function showToast(message) {
    toastNode.textContent = message;
    toastNode.classList.add('show');
    clearTimeout(showToast.timer);
    showToast.timer = setTimeout(() => toastNode.classList.remove('show'), 3200);
  }

  function statusClass(status) {
    const value = legacyStatuses[status] || status;
    return ({ pending: 'new', confirmed: 'new', searching_driver: 'new', assigned: 'progress', driver_accepted: 'progress', heading_to_pickup: 'progress', arrived_pickup: 'progress', picked_up: 'progress', delivering: 'progress', arrived_destination: 'progress', delivered: 'success', cancelled: 'danger', rejected: 'danger', failed: 'danger' }[value] || 'neutral');
  }

  function statusBadge(text) {
    return `<span class="status ${statusClass(text)}">${escapeHTML(text)}</span>`;
  }

  function brand() {
    return `<a class="brand" href="#" data-action="go-home"><img class="brand-mark" src="icon.svg" alt="" /><span>مشاوير<small>توصيل أسرع من باب لباب</small></span></a>`;
  }

  function render() {
    if (!state.user) app.innerHTML = landingView();
    else if (currentRole() === 'customer') app.innerHTML = customerView();
    else app.innerHTML = dashboardView();
    if (state.modal) app.insertAdjacentHTML('beforeend', modalView());
    if (state.user?.demo) app.insertAdjacentHTML('beforeend', demoRibbon());
  }

  function landingView() {
    return `<div class="app-shell">
      <header class="topbar container">${brand()}<div class="nav-actions"><button class="ghost-button" data-action="open-auth" data-mode="login" data-role="customer">دخول مستخدم</button><button class="ghost-button" data-action="open-auth" data-mode="login" data-role="courier">دخول مندوب</button><button class="ghost-button" data-action="open-auth" data-mode="login" data-role="admin">دخول مدير</button><button class="primary-button" data-action="open-auth" data-mode="signup" data-role="customer">إنشاء حساب</button></div></header>
      <main>
        <section class="hero-wrap container"><div class="hero"><div class="hero-copy"><div class="eyebrow">كل طلبات القرية في مشوار واحد</div><h1>اللي تحتاجه،<br />يوصلك أسرع.</h1><p>مطاعم، بقالة، صيدلية وطرود من محلات قريتك إلى بابك، مع متابعة واضحة من أول الطلب حتى التسليم.</p><button class="primary-button hero-cta" data-action="open-auth" data-mode="signup">ابدأ مشوارك <span>←</span></button></div><div class="hero-orbit"><div class="speed-lines"></div><div class="scooter">🛵</div></div></div></section>
        <section class="section container"><div class="promo-strip"><div><strong>مشوارك في أمان</strong><span>ادفع للمحل، أو استخدم Vodafone Cash وInstaPay بالطريقة التي تناسبك.</span></div><div class="promo-badge">✦</div></div></section>
        <section class="section container"><div class="section-heading"><div><h2>اختار من محلات قريتك</h2><p>كل مكان قريب، وكل طلب له متابعة.</p></div><button class="link-button" data-action="open-auth" data-mode="signup">شاهد الكل ←</button></div><div class="merchant-grid">${merchants.map(merchantCard).join('')}</div></section>
      </main>
      <footer class="site-footer"><div class="container footer-inner"><span class="footer-brand">مشاوير</span><span>خدمة توصيل محلية قابلة للتوسع لكل القرى</span></div></footer>
    </div>`;
  }

  function merchantCard(merchant) {
    return `<article class="merchant-card" data-action="choose-merchant" data-merchant="${merchant.id}"><div class="merchant-cover" style="background:${merchant.color}"><strong>${escapeHTML(merchant.name)}</strong><span>${escapeHTML(merchant.description)}</span><div class="merchant-symbol">${merchant.symbol}</div></div><div class="merchant-body"><div class="merchant-title"><h3>${escapeHTML(merchant.name)}</h3><span class="rating">★ 4.8</span></div><div class="meta-row"><span>توصيل ${merchant.eta}</span><span>${money(merchant.fee)}</span></div></div></article>`;
  }

  function customerView() {
    const name = state.profile?.full_name || state.user?.user_metadata?.full_name || 'يا صديقي';
    const filtered = products.filter((product) => (state.selectedCategory === 'الكل' || product.category === state.selectedCategory) && (!state.selectedMerchant || product.merchant_id === state.selectedMerchant));
    return `<div class="app-shell"><header class="topbar container">${brand()}<div class="nav-actions"><button class="icon-button" data-action="open-orders" title="طلباتي">◷</button><button class="icon-button" data-action="open-cart" title="السلة">🛒<sup>${state.cart.reduce((s, item) => s + item.quantity, 0) || ''}</sup></button><button class="avatar" data-action="logout" title="تسجيل الخروج">${escapeHTML(initials(name))}</button></div></header>
      <main>
        <section class="hero-wrap container"><div class="hero"><div class="hero-copy"><div class="eyebrow">أهلاً ${escapeHTML(name.split(' ')[0])}، جاهز للمشوار؟</div><h1>اطلبها.<br />واحنا نوصلها.</h1><p>اختار من محلات قريتك، اكتب عنوانك، وخلي الباقي علينا.</p><button class="primary-button hero-cta" data-action="scroll-products">ابدأ الطلب <span>←</span></button></div><div class="hero-orbit"><div class="speed-lines"></div><div class="scooter">🛵</div></div></div></section>
        <section class="section container"><div class="section-heading"><div><h2>تسوق حسب احتياجك</h2><p>كل ما تحتاجه، قريب منك.</p></div></div><div class="chips">${categories.map((category) => `<button class="chip ${state.selectedCategory === category ? 'active' : ''}" data-action="category" data-category="${category}">${category}</button>`).join('')}</div></section>
        <section class="section container"><div class="section-heading"><div><h2>${state.selectedMerchant ? escapeHTML(selectedMerchant().name) : 'محلات مميزة'}</h2><p>${state.selectedMerchant ? 'اختر اللي نفسك فيه واضفه للسلة.' : 'أماكن موثوقة، ووقت توصيل واضح.'}</p></div>${state.selectedMerchant ? '<button class="link-button" data-action="clear-merchant">كل المحلات ←</button>' : ''}</div><div class="merchant-grid">${merchants.filter((m) => state.selectedCategory === 'الكل' || m.category === state.selectedCategory).map(merchantCard).join('')}</div></section>
        <section id="products" class="section container"><div class="section-heading"><div><h2>اختيارات اليوم</h2><p>${state.cart.length ? `في السلة ${state.cart.length} أصناف جاهزة للمراجعة.` : 'اضغط + لإضافة أي صنف إلى السلة.'}</p></div><button class="link-button" data-action="open-cart">السلة (${state.cart.reduce((s, item) => s + item.quantity, 0)}) ←</button></div><div class="product-grid">${filtered.map(productCard).join('') || '<div class="empty-state">لا توجد أصناف في هذا القسم بعد.</div>'}</div></section>
        ${ordersSection()}
      </main><footer class="site-footer"><div class="container footer-inner"><span class="footer-brand">مشاوير</span><span>طلبك تحت المتابعة حتى بابك</span><button class="link-button" data-action="logout">خروج</button></div></footer>
    </div>`;
  }

  function productCard(product) {
    return `<article class="product-card"><div class="product-thumb">${product.emoji}</div><h3>${escapeHTML(product.name)}</h3><p>${escapeHTML(product.description)}</p><div class="product-footer"><span class="price">${money(product.price)}</span><button class="add-button" data-action="add-cart" data-product="${product.id}" aria-label="إضافة">+</button></div></article>`;
  }

  function ordersSection() {
    const orders = state.orders.slice(0, 3);
    return `<section id="orders" class="section container"><div class="section-heading"><div><h2>آخر طلباتك</h2><p>تقدر تتابع كل مشوار من هنا.</p></div><button class="link-button" data-action="show-notice" data-message="صفحة سجل الطلبات الكاملة ستكون متاحة في الإصدار التالي.">كل الطلبات ←</button></div><div class="dashboard-card">${orders.length ? orders.map((order) => `<div class="courier-order"><div class="order-main"><strong>${escapeHTML(order.merchant || 'طلب مشاوير')}</strong><span>${escapeHTML(order.address || 'العنوان غير محدد')} · ${escapeHTML(order.created_at || 'الآن')}</span></div><div class="order-actions">${statusBadge(order.statusText || order.status || 'جديد')}<strong>${money(order.total)}</strong></div></div>`).join('') : '<div class="empty-state">لم تطلب شيئًا بعد. أول مشوار مستنيك.</div>'}</div></section>`;
  }

  function dashboardView() {
    return `<div class="dashboard-layout"><aside class="side-panel">${brand()}<nav class="side-nav">${dashboardNav()}</nav><div class="side-footer">مشاوير<br />لوحة ${roleName(currentRole())}<br /><span>الإصدار 1.0</span></div></aside><main class="dashboard-main">${dashboardTop()}${currentRole() === 'admin' ? adminView() : courierView()}</main><nav class="mobile-nav">${dashboardNav(true)}</nav></div>`;
  }

  function dashboardNav(mobile = false) {
    const items = currentRole() === 'admin' ? [['overview', '⌂', 'نظرة عامة'], ['orders', '▣', 'الطلبات'], ['couriers', '♙', 'المندوبون'], ['shops', '⌁', 'المحلات']] : [['overview', '⌂', 'الرئيسية'], ['orders', '▣', 'طلباتي'], ['earnings', '◈', 'أرباحي']];
    return items.map(([id, icon, label]) => `<button class="${(state.adminTab === id || (!state.adminTab && id === 'overview')) ? 'active' : ''}" data-action="dashboard-tab" data-tab="${id}"><b>${icon}</b>${mobile ? `<span>${label}</span>` : label}</button>`).join('') + `<button data-action="logout"><b>↪</b>${mobile ? '<span>خروج</span>' : 'تسجيل الخروج'}</button>`;
  }

  function dashboardTop() {
    const name = state.profile?.full_name || state.user?.user_metadata?.full_name || roleName(currentRole());
    return `<div class="dashboard-top"><div><h1>${currentRole() === 'admin' ? 'صباح الخير، مدير مشاوير' : `أهلاً ${escapeHTML(name.split(' ')[0])}`}</h1><p>${currentRole() === 'admin' ? 'تابع الحركة، الطلبات والمندوبين من مكان واحد.' : 'خليك متابع، وكل مشوار له حسابه.'}</p></div><div class="button-row"><button class="icon-button" data-action="show-notice" data-message="لا توجد إشعارات جديدة.">♧</button><button class="avatar" data-action="logout">${escapeHTML(initials(name))}</button></div></div>`;
  }

  function adminView() {
    const courierList = isDemo() ? demoCouriers : state.couriers;
    const counts = { all: state.orders.length, new: state.orders.filter((o) => o.statusText === 'جديد').length, couriers: courierList.length, revenue: state.orders.reduce((sum, order) => sum + Number(order.delivery_fee || 0), 0) };
    return `<section class="stats-grid"><div class="stat-card"><span class="stat-label">طلبات اليوم</span><strong>${counts.all}</strong><span class="stat-note">+12% عن أمس</span></div><div class="stat-card"><span class="stat-label">تحتاج متابعة</span><strong>${counts.new}</strong><span class="stat-note">طلبات جديدة</span></div><div class="stat-card"><span class="stat-label">المندوبون</span><strong>${counts.couriers}</strong><span class="stat-note">${demoCouriers.filter((c) => c.approved).length} موافق عليهم</span></div><div class="stat-card"><span class="stat-label">إجمالي التوصيل</span><strong>${money(counts.revenue)}</strong><span class="stat-note">هذا الشهر</span></div></section>${state.adminTab === 'overview' || state.adminTab === 'orders' ? adminOrders() : state.adminTab === 'couriers' ? adminCouriers() : adminShops()}`;
  }

  function adminOrders() {
    const rows = (isDemo() ? state.orders : state.orders).slice(0, 10);
    return `<section class="dashboard-card"><div class="card-heading"><div><h2>حركة الطلبات</h2><span>كل الطلبات في مكان واحد</span></div><button class="primary-button small-button" data-action="show-notice" data-message="إضافة طلب يدوي متاحة من لوحة الطلبات القادمة.">+ طلب جديد</button></div>${rows.length ? `<div class="table-wrap"><table class="data-table"><thead><tr><th>رقم الطلب</th><th>العميل</th><th>المحل</th><th>الحالة</th><th>الإجمالي</th><th></th></tr></thead><tbody>${rows.map((order, index) => `<tr><td><strong>${escapeHTML(order.id || `MW-${1040 - index}`)}</strong></td><td>${escapeHTML(order.customer || 'عميل مشاوير')}</td><td>${escapeHTML(order.merchant || 'متجر')}</td><td>${statusBadge(order.statusText || 'جديد')}</td><td>${money(order.total)}</td><td><button class="ghost-button small-button" data-action="advance-order" data-order-id="${escapeHTML(order.id || '')}">تحديث</button></td></tr>`).join('')}</tbody></table></div>` : '<div class="empty-state">لا توجد طلبات حتى الآن.</div>'}</section>`;
  }

  function adminCouriers() {
    const couriers = isDemo() ? demoCouriers : state.couriers;
    return `<section class="dashboard-card"><div class="card-heading"><div><h2>المندوبون</h2><span>الموافقة والمتابعة والأرباح الخاصة بكل مندوب</span></div><button class="primary-button small-button" data-action="show-notice" data-message="يمكن فتح التسجيل العام للمندوبين من الإعدادات.">دعوة مندوب</button></div>${couriers.length ? `<div class="table-wrap"><table class="data-table"><thead><tr><th>المندوب</th><th>الهاتف</th><th>الحالة</th><th>الطلبات</th><th>الأرباح</th><th></th></tr></thead><tbody>${couriers.map((courier) => `<tr><td><strong>${escapeHTML(courier.full_name || courier.name || 'مندوب')}</strong></td><td>${escapeHTML(courier.phone || '')}</td><td>${courier.approved === false ? '<span class="status new">بانتظار الموافقة</span>' : statusBadge(courier.status || 'نشط')}</td><td>${courier.orders || 0}</td><td>${money(courier.earnings || 0)}</td><td><button class="ghost-button small-button" data-action="approve-courier" data-courier-id="${escapeHTML(courier.id || '')}" data-courier="${escapeHTML(courier.full_name || courier.name || 'مندوب')}">${courier.approved === false ? 'موافقة' : 'الملف'}</button></td></tr>`).join('')}</tbody></table></div>` : '<div class="empty-state">لا يوجد مندوبون مسجلون بعد.</div>'}</section>`;
  }

  function adminShops() {
    return `<section class="dashboard-card"><div class="card-heading"><div><h2>المحلات والرسوم</h2><span>أضف المحلات، الأقسام، ومنطقة التوصيل</span></div><button class="primary-button small-button" data-action="show-notice" data-message="نموذج إضافة محل جديد جاهز للربط بقاعدة البيانات.">+ إضافة محل</button></div><div class="merchant-grid">${merchants.map((merchant) => `<div class="merchant-card"><div class="merchant-cover" style="background:${merchant.color}"><strong>${escapeHTML(merchant.name)}</strong><span>${escapeHTML(merchant.category)}</span><div class="merchant-symbol">${merchant.symbol}</div></div><div class="merchant-body"><div class="merchant-title"><h3>${money(merchant.fee)}</h3><span class="status success">نشط</span></div><div class="meta-row"><span>رسوم التوصيل الحالية</span><button class="link-button" data-action="show-notice" data-message="تعديل الرسوم سيكون حسب المنطقة أو النسبة.">تعديل</button></div></div></div>`).join('')}</div></section>`;
  }

  function courierView() {
    const approved = state.profile?.approved !== false;
    if (!approved && !isDemo()) return `<section class="dashboard-card"><div class="empty-state"><div style="font-size:42px;margin-bottom:10px">🛵</div><h2>حسابك قيد المراجعة</h2><p>سيظهر لك الطلب بمجرد موافقة الإدارة على حساب المندوب.</p></div></section>`;
    const assigned = state.orders.slice(0, 3);
    const earnings = assigned.reduce((sum, order) => sum + Number(order.delivery_fee || 0), 0);
    return `<section class="stats-grid"><div class="stat-card"><span class="stat-label">طلبات اليوم</span><strong>${assigned.length}</strong><span class="stat-note">طلبات مسندة إليك</span></div><div class="stat-card"><span class="stat-label">أرباحي الحالية</span><strong>${money(earnings)}</strong><span class="stat-note">من رسوم التوصيل</span></div><div class="stat-card"><span class="stat-label">إجمالي الطلبات</span><strong>${state.orders.length}</strong><span class="stat-note">الطلبات الخاصة بك</span></div><div class="stat-card"><span class="stat-label">الحالة الآن</span><strong style="font-size:20px">${state.courierOnline ? 'متاح' : 'غير متاح'}</strong><span class="stat-note">${state.courierOnline ? 'تستقبل طلبات' : 'لن تستقبل طلبات'}</span></div></section><section class="dashboard-card"><div class="card-heading"><div><h2>حالة المندوب</h2><span>فعّل ظهورك لاستقبال مشاوير جديدة</span></div><button class="toggle ${state.courierOnline ? 'on' : ''}" data-action="toggle-online"><i></i></button></div><div class="notice">نصيحة: حدّث حالة الطلب فور الاستلام والتسليم حتى يطمئن العميل.</div></section><section class="dashboard-card"><div class="card-heading"><div><h2>المشاوير الحالية</h2><span>الطلبات الخاصة بك فقط</span></div><span>${assigned.length} طلب</span></div>${assigned.length ? assigned.map((order) => `<div class="courier-order"><div class="order-main"><strong>${escapeHTML(order.merchant || 'طلب مشاوير')}</strong><span>${escapeHTML(order.address || 'العنوان')} · ${escapeHTML(order.customer || 'عميل')}</span></div><div class="order-actions">${statusBadge(order.statusText || 'جديد')}<button class="primary-button small-button" data-action="advance-order" data-order-id="${escapeHTML(order.id || '')}">تحديث الحالة</button></div></div>`).join('') : '<div class="empty-state">لا توجد طلبات مسندة إليك.</div>'}</section>`;
  }

  function demoRibbon() {
    return `<div class="demo-ribbon">وضع التجربة · <button data-action="switch-demo" data-view="customer">مستخدم</button> · <button data-action="switch-demo" data-view="courier">مندوب</button> · <button data-action="switch-demo" data-view="admin">إدارة</button></div>`;
  }

  function adminView() {
    const rows = state.orders.slice(0, 10);
    const couriers = isDemo() ? demoCouriers : state.couriers;
    const revenue = state.orders.reduce((sum, order) => sum + Number(order.delivery_fee || 0), 0);
    const courierOptions = (order) => `<select class="assign-select" data-action="assign-order" data-order-id="${escapeHTML(order.id || '')}" aria-label="توجيه الطلب"><option value="">غير موجّه</option>${couriers.filter((courier) => courier.approved !== false).map((courier) => `<option value="${escapeHTML(courier.id || '')}" ${String(order.courier_id || '') === String(courier.id || '') ? 'selected' : ''}>${escapeHTML(courier.full_name || courier.name || 'مندوب')}</option>`).join('')}</select>`;
    return `<section class="dashboard-kpis"><div><span>طلبات اليوم</span><strong>${state.orders.length}</strong><small>متزامنة مع النظام</small></div><div><span>تم التسليم</span><strong>${state.orders.filter((o) => o.statusText === 'تم التسليم').length}</strong><small>بنجاح</small></div><div><span>قيد التنفيذ</span><strong>${state.orders.filter((o) => o.statusText !== 'تم التسليم').length}</strong><small>تحتاج متابعة</small></div><div><span>إجمالي التوصيل</span><strong>${money(revenue)}</strong><small>هذا الشهر</small></div></section><section class="admin-panel"><div class="panel-title"><div><span class="section-kicker">الحركة الآن</span><h2>إدارة وتوجيه الطلبات</h2></div><span class="count-pill">${rows.length}</span></div><p class="panel-help">عند اختيار مندوب، يظهر الطلب فورًا في تطبيقه ويظل ظاهرًا للعميل والإدارة.</p><div class="admin-order-list">${rows.length ? rows.map((order) => `<div class="admin-order-row"><span class="order-number">#${escapeHTML(String(order.id || '').slice(-4) || '1258')}</span><span><b>${escapeHTML(order.merchant || 'طلب مشاوير')}</b><small>${escapeHTML(order.customer || 'عميل')} · ${escapeHTML(order.address || 'العنوان')}</small></span>${statusBadge(order.statusText || 'جديد')}<div class="admin-assignment">${courierOptions(order)}<button class="link-button" data-action="track-order" data-order-id="${escapeHTML(order.id || '')}">تفاصيل</button></div></div>`).join('') : '<div class="empty-state">لا توجد طلبات حقيقية بعد.</div>'}</div></section><section class="admin-panel"><div class="panel-title"><div><span class="section-kicker">فريق التوصيل</span><h2>المندوبون</h2></div><span class="count-pill">${couriers.length}</span></div><div class="people-list">${couriers.slice(0, 8).map((courier) => `<div class="person-row"><span class="person-avatar">${escapeHTML(initials(courier.full_name || courier.name))}</span><span><b>${escapeHTML(courier.full_name || courier.name || 'مندوب')}</b><small>${escapeHTML(courier.phone || '')}</small></span><span class="person-state ${courier.approved === false ? 'pending' : ''}">${courier.approved === false ? 'بانتظار الموافقة' : 'متاح'}</span>${courier.approved === false ? `<button class="link-button" data-action="approve-courier" data-courier-id="${escapeHTML(courier.id || '')}" data-courier="${escapeHTML(courier.full_name || courier.name || 'مندوب')}">موافقة</button>` : ''}</div>`).join('') || '<div class="empty-state">لا يوجد مندوبون بعد.</div>'}</div></section>`;
  }

  async function assignOrder(orderId, courierId) {
    const order = state.orders.find((item) => String(item.id) === String(orderId));
    if (!order || !client || isDemo()) return;
    const { data, error } = await client.rpc('assign_order', { order_id_value: orderId, courier_id_value: courierId || null });
    if (error) return showToast(error.message || 'تعذر توجيه الطلب. تأكد من صلاحية المدير.');
    Object.assign(order, mapOrder(Array.isArray(data) ? data[0] : data));
    render();
    showToast(courierId ? 'تم توجيه الطلب وسيظهر للمندوب الآن.' : 'تم إلغاء توجيه الطلب.');
  }

  function handleChange(event) {
    const target = event.target.closest('[data-action]');
    if (!target) return;
    if (target.dataset.action === 'assign-order') assignOrder(target.dataset.orderId, target.value);
    if (target.dataset.action === 'change-order-status') advanceOrder(target.dataset.orderId, target.value);
  }

  function modalView() {
    return `<div class="modal-backdrop" data-action="backdrop"><section class="modal ${state.modal === 'cart' ? 'modal-wide' : ''}" role="dialog" aria-modal="true">${state.modal === 'auth' ? authModal() : cartModal()}</section></div>`;
  }

  function authModalLegacy() {
    const mode = state.authMode;
    const title = mode === 'signup' ? 'ابدأ أول مشوار' : mode === 'forgot' ? 'استرجاع كلمة المرور' : 'أهلاً بك في مشاوير';
    const subtitle = mode === 'signup' ? 'حسابك يفتح في دقيقة، وبدون رسائل أو أكواد.' : mode === 'forgot' ? 'استخدم رقم الهاتف وPIN الاسترجاع الذي اخترته عند التسجيل.' : 'سجل دخولك وتابع طلبك حتى بابك.';
    return `<div class="modal-head"><div><h2>${title}</h2><p>${subtitle}</p></div><button class="close-button" data-action="close-modal">×</button></div><div class="modal-body">${mode !== 'forgot' ? `<div class="auth-tabs"><button class="${mode === 'login' ? 'active' : ''}" data-action="auth-mode" data-mode="login">تسجيل الدخول</button><button class="${mode === 'signup' ? 'active' : ''}" data-action="auth-mode" data-mode="signup">حساب جديد</button></div>` : ''}<form id="auth-form" class="form-grid"><input type="hidden" name="mode" value="${mode}" />${mode === 'signup' ? `<div class="field"><label>الاسم بالكامل</label><input name="full_name" required autocomplete="name" placeholder="مثال: أحمد محمد" /></div>` : ''}<div class="field"><label>رقم الهاتف</label><input name="phone" required inputmode="tel" autocomplete="tel" placeholder="01xxxxxxxxx" /></div>${mode !== 'forgot' ? `<div class="field"><label>كلمة المرور</label><div class="password-row"><input name="password" type="password" required minlength="6" autocomplete="${mode === 'signup' ? 'new-password' : 'current-password'}" placeholder="6 أحرف أو أكثر" /><button type="button" class="password-toggle" data-action="toggle-password">◉</button></div></div>` : `<div class="field"><label>PIN الاسترجاع</label><input name="pin" required inputmode="numeric" pattern="[0-9]{6}" maxlength="6" placeholder="6 أرقام" /></div><div class="field"><label>كلمة المرور الجديدة</label><input name="password" type="password" required minlength="6" autocomplete="new-password" placeholder="كلمة مرور جديدة" /></div>`}${mode === 'signup' ? `<div class="field"><label>PIN الاسترجاع</label><input name="pin" required inputmode="numeric" pattern="[0-9]{6}" maxlength="6" placeholder="6 أرقام لا يعرفها أحد غيرك" /></div><div class="form-note">الـPIN ليس كودًا يُرسل إليك؛ هو مفتاح استرجاع تختاره وتحفظه لنفسك. لا تشاركه مع أي شخص.</div>` : ''}<button class="primary-button" type="submit">${mode === 'signup' ? 'إنشاء الحساب' : mode === 'forgot' ? 'تغيير كلمة المرور' : 'دخول آمن'}</button>${mode === 'login' ? '<button type="button" class="link-button" data-action="auth-mode" data-mode="forgot">نسيت كلمة المرور؟ استخدم PIN الاسترجاع</button>' : mode === 'forgot' ? '<button type="button" class="link-button" data-action="auth-mode" data-mode="login">العودة لتسجيل الدخول</button>' : ''}<div class="form-note">للتجربة الآن: يمكنك استعراض واجهات المستخدم والمندوب والإدارة من زر التجربة أسفل الصفحة.</div></form></div>`;
  }

  function authModal() {
    const mode = state.authMode;
    const roleLabel = roleName(state.authRole);
    const title = mode === 'signup' ? (state.authRole === 'courier' ? 'انضم كمندوب' : 'ابدأ أول مشوار') : mode === 'forgot' ? 'استرجاع كلمة المرور' : `دخول ${roleLabel}`;
    const subtitle = mode === 'signup' ? (state.authRole === 'courier' ? 'سجّل بياناتك للانضمام إلى فريق المندوبين.' : 'حسابك يفتح في دقيقة، وبدون رسائل أو أكواد.') : mode === 'forgot' ? 'استخدم رقم الهاتف وPIN الاسترجاع الذي اخترته عند التسجيل.' : `سجّل دخولك إلى واجهة ${roleLabel}.`;
    const roleTabs = mode !== 'forgot' ? `<div class="role-tabs">${(mode === 'login' ? loginRoles : signupRoles).map((role) => `<button class="${state.authRole === role ? 'active' : ''}" data-action="auth-role" data-role="${role}">${roleName(role)}</button>`).join('')}</div>` : '';
    const courierNote = mode === 'signup' && state.authRole === 'courier' ? '<div class="form-note">حساب المندوب يبدأ بانتظار موافقة الإدارة قبل استقبال الطلبات.</div>' : '';
    return `<div class="modal-head"><div><h2>${title}</h2><p>${subtitle}</p></div><button class="close-button" data-action="close-modal">×</button></div><div class="modal-body">${mode !== 'forgot' ? `<div class="auth-tabs"><button class="${mode === 'login' ? 'active' : ''}" data-action="auth-mode" data-mode="login">تسجيل الدخول</button><button class="${mode === 'signup' ? 'active' : ''}" data-action="auth-mode" data-mode="signup">حساب جديد</button></div>` : ''}${roleTabs}<form id="auth-form" class="form-grid"><input type="hidden" name="mode" value="${mode}" /><input type="hidden" name="role" value="${state.authRole}" />${mode === 'signup' ? `<div class="field"><label>الاسم بالكامل</label><input name="full_name" required autocomplete="name" placeholder="مثال: أحمد محمد" /></div>` : ''}<div class="field"><label>رقم الهاتف</label><input name="phone" required inputmode="tel" autocomplete="tel" placeholder="01xxxxxxxxx" /></div>${mode !== 'forgot' ? `<div class="field"><label>كلمة المرور</label><div class="password-row"><input name="password" type="password" required minlength="6" autocomplete="${mode === 'signup' ? 'new-password' : 'current-password'}" placeholder="6 أحرف أو أكثر" /><button type="button" class="password-toggle" data-action="toggle-password">◉</button></div></div>` : `<div class="field"><label>PIN الاسترجاع</label><input name="pin" required inputmode="numeric" pattern="[0-9]{6}" maxlength="6" placeholder="6 أرقام" /></div><div class="field"><label>كلمة المرور الجديدة</label><input name="password" type="password" required minlength="6" autocomplete="new-password" placeholder="كلمة مرور جديدة" /></div>`}${mode === 'signup' ? `<div class="field"><label>PIN الاسترجاع</label><input name="pin" required inputmode="numeric" pattern="[0-9]{6}" maxlength="6" placeholder="6 أرقام لا يعرفها أحد غيرك" /></div><div class="form-note">الـPIN ليس كودًا يُرسل إليك؛ هو مفتاح استرجاع تختاره وتحفظه لنفسك. لا تشاركه مع أي شخص.</div>${courierNote}` : ''}<button class="primary-button" type="submit">${mode === 'signup' ? (state.authRole === 'courier' ? 'إنشاء حساب مندوب' : 'إنشاء الحساب') : mode === 'forgot' ? 'تغيير كلمة المرور' : 'تسجيل الدخول'}</button></form>${mode !== 'forgot' ? `<button class="link-button auth-forgot" data-action="auth-mode" data-mode="forgot">نسيت كلمة المرور؟</button>` : `<button class="link-button auth-forgot" data-action="auth-mode" data-mode="login">العودة لتسجيل الدخول</button>`}</div>`;
  }

  function cartModal() {
    const subtotal = cartSubtotal();
    return `<div class="modal-head"><div><h2>راجع مشوارك</h2><p>${selectedMerchant() ? escapeHTML(selectedMerchant().name) : 'أضف أصنافًا من محل واحد لكل طلب.'}</p></div><button class="close-button" data-action="close-modal">×</button></div><div class="modal-body">${state.cart.length ? `<div>${state.cart.map(cartLine).join('')}</div><div class="form-grid" style="margin-top:16px"><div class="field"><label>عنوان التوصيل بالوصف</label><textarea name="address" id="address-input" placeholder="اسم الشارع، علامة مميزة، الدور...">${escapeHTML(state.checkoutAddress || '')}</textarea></div><div class="map-box"><span>📍 ${state.location ? 'تم تحديد موقعك على الخريطة' : 'أضف موقعك لمساعدة المندوب'}</span><button type="button" class="ghost-button small-button" data-action="locate">${state.location ? 'تحديث الموقع' : 'استخدم موقعي'}</button></div><div class="field"><label>رقم للتواصل عند الوصول</label><input id="checkout-phone" name="checkout_phone" inputmode="tel" value="${escapeHTML(state.user?.phone || '')}" placeholder="01xxxxxxxxx" /></div><div class="field"><label>طريقة الدفع أو التسوية</label><div class="payment-list"><label class="payment-option"><input type="radio" name="payment" value="paid_to_store" checked /><span>دفعت للمحل، والمطلوب توصيل فقط</span></label><label class="payment-option"><input type="radio" name="payment" value="vodafone_cash" /><span>Vodafone Cash</span></label><label class="payment-option"><input type="radio" name="payment" value="instapay" /><span>InstaPay</span></label><label class="payment-option"><input type="radio" name="payment" value="cash" /><span>الدفع عند الاستلام</span></label></div></div><div class="field"><label>رقم العملية، إن وجد</label><input id="payment-ref" placeholder="اختياري" /></div><div class="order-total"><span>الإجمالي التقريبي</span><span>${money(subtotal)} + ${money(cartFee())} توصيل = ${money(cartTotal())}</span></div><button class="primary-button" data-action="submit-order">تأكيد الطلب · ${money(cartTotal())}</button></div>` : '<div class="empty-state"><div style="font-size:46px">🛒</div><h3>السلة فاضية</h3><p>اختار طلبك الأول من المطاعم والمحلات.</p><button class="primary-button" data-action="close-modal">ابدأ التسوق</button></div>'}</div>`;
  }

  function cartLine(line) {
    return `<div class="cart-line"><div class="line-info"><strong>${escapeHTML(line.name)}</strong><span>${money(line.price)} · ${escapeHTML(line.merchantName)}</span></div><div class="quantity"><button data-action="cart-dec" data-product="${line.id}">−</button><b>${line.quantity}</b><button data-action="cart-inc" data-product="${line.id}">+</button></div></div>`;
  }

  async function loadProfile(user) {
    if (!client || !user) return;
    const { data } = await client.from('profiles').select('*').eq('id', user.id).maybeSingle();
    state.profile = data || { full_name: user.user_metadata?.full_name || 'عميل مشاوير', role: user.user_metadata?.role || 'customer', approved: true };
    state.view = state.profile.role === 'customer' ? 'customer' : state.profile.role;
    const { data: orderData } = await client.from('orders').select('*').order('created_at', { ascending: false }).limit(10);
    if (orderData) state.orders = orderData.map(mapOrder);
    if (state.orders.length) {
      await Promise.all(state.orders.filter((order) => order.courier_id).map(async (order) => {
        const { data } = await client.rpc('order_courier_summary', { order_id_value: order.id });
        if (data) order.courier = data;
      }));
    }
    const { data: notificationData } = await client.from('notifications').select('*').is('read_at', null).order('created_at', { ascending: false }).limit(10);
    if (notificationData) state.notifications = notificationData;
    if (state.profile.role === 'admin') {
      const { data: courierData } = await client.from('profiles').select('*').eq('role', 'courier').order('created_at', { ascending: false });
      if (courierData) state.couriers = courierData;
    }
  }

  async function loadCatalog() {
    if (!client) return;
    const { data: merchantData } = await client.from('merchants').select('*').eq('active', true).order('created_at');
    const { data: productData } = await client.from('products').select('*').eq('available', true).order('created_at');
    if (merchantData?.length) {
      merchants = merchantData.map((merchant, index) => ({
        ...merchant,
        fee: Number(merchant.delivery_value || 18),
        eta: '25 - 45 دقيقة',
        color: ['linear-gradient(135deg,#e76f39,#9e3b31)', 'linear-gradient(135deg,#2d8a70,#1c5360)', 'linear-gradient(135deg,#3e8bc4,#3565a5)'][index % 3],
        symbol: ['🍲', '🛒', '✚'][index % 3]
      }));
    }
    if (productData?.length) {
      products = productData.map((product, index) => ({ ...product, price: Number(product.price), emoji: ['🍗', '🥘', '🌯', '🥬', '💧', '🧺', '💊', '🩹'][index % 8] }));
    }
  }

  function mapOrder(order) {
    const merchant = merchantFor(order.merchant_id);
    const status = orderLabels[order.status] ? order.status : (legacyStatuses[order.status] || 'pending');
    return { ...order, status, merchant: merchant?.name || 'طلب مشاوير', statusText: orderLabels[status], total: order.total || 0, address: order.address_text || '' };
  }

  async function completeAuth(user) {
    state.user = user;
    await loadProfile(user);
    if (client && !state.liveChannel) {
      state.liveChannel = client.channel('mashwer-orders-live').on('postgres_changes', { event: '*', schema: 'public', table: 'orders' }, async () => {
        await loadProfile(state.user);
        render();
      }).subscribe();
    }
    if (client && !state.refreshTimer) {
      state.refreshTimer = window.setInterval(async () => {
        if (!state.user || state.user.demo || state.modal) return;
        await loadProfile(state.user);
        render();
      }, 10000);
    }
    state.modal = null;
    render();
  }

  async function submitAuth(form) {
    const data = new FormData(form);
    const mode = String(data.get('mode'));
    const phone = normalizePhone(data.get('phone'));
    const password = String(data.get('password') || '');
    state.busy = true;
    render();
    try {
      if (mode === 'login') {
        const expectedRole = String(data.get('role') || 'customer');
        if (!loginRoles.includes(expectedRole)) throw new Error('نوع الدخول غير صحيح.');
        if (!client) return demoLogin(expectedRole);
        const result = await client.auth.signInWithPassword({ email: authEmail(phone), password });
        if (result.error) throw new Error(authErrorMessage(result.error));
        await loadProfile(result.data.user);
        const actualRole = currentRole();
        if (actualRole !== expectedRole) {
          await client.auth.signOut();
          state.profile = null;
          throw new Error(`هذا الحساب مسجل كـ${roleName(actualRole)}. اختر واجهة الدخول المناسبة.`);
        }
        await completeAuth(result.data.user);
        showToast('تم تسجيل الدخول، أهلاً بك في مشاوير.');
      } else if (mode === 'signup') {
        const fullName = String(data.get('full_name') || '').trim();
        const pin = String(data.get('pin') || '');
        const requestedRole = String(data.get('role') || 'customer');
        if (!/^\+20\d{10}$/.test(phone)) throw new Error('اكتب رقم هاتف مصري صحيحًا مثل 01012345678.');
        if (password.length < 6) throw new Error('كلمة المرور يجب أن تكون 6 أحرف أو أرقام على الأقل.');
        if (!/^\d{6}$/.test(pin)) throw new Error('PIN الاسترجاع يجب أن يكون 6 أرقام.');
        if (!['customer', 'courier'].includes(requestedRole)) throw new Error('إنشاء حساب المدير يتم من الإدارة فقط.');
        if (!client) return demoLogin(requestedRole, fullName || 'عميل مشاوير');
        const result = await client.auth.signUp({ email: authEmail(phone), password, options: { data: { full_name: fullName, phone, role: requestedRole } } });
        if (result.error) throw new Error(authErrorMessage(result.error));
        if (!result.data.session) throw new Error('تعذر فتح الحساب تلقائيًا. تأكد من إيقاف تأكيد البريد في Supabase.');
        const pinResult = await client.rpc('set_pin', { pin_value: pin });
        if (pinResult.error) throw new Error(`تم إنشاء الحساب، لكن تعذر حفظ PIN الاسترجاع: ${authErrorMessage(pinResult.error)}`);
        await completeAuth(result.data.user);
        showToast('تم إنشاء حسابك بنجاح.');
      } else {
        const pin = String(data.get('pin') || '');
        if (!/^\d{6}$/.test(pin)) throw new Error('اكتب PIN صحيحًا من 6 أرقام.');
        if (!client) throw new Error('وضع التجربة لا ينفذ استعادة حقيقية.');
        const result = await client.rpc('recover_password', { phone_value: phone, pin_value: pin, new_password: password });
        if (result.error || !result.data?.ok) throw new Error(result.error?.message || result.data?.error || 'تعذر الاسترجاع.');
        state.authMode = 'login';
        render();
        showToast('تم تغيير كلمة المرور. سجل دخولك الآن.');
      }
    } catch (error) {
      showToast(error.message || 'حدث خطأ، حاول مرة أخرى.');
      render();
    } finally {
      state.busy = false;
    }
  }

  function demoLogin(role = 'customer', name = '') {
    state.user = { id: `demo-${role}`, phone: '+201000000000', demo: true, user_metadata: { full_name: name || (role === 'admin' ? 'مدير مشاوير' : role === 'courier' ? 'مندوب مشاوير' : 'عميل مشاوير'), role } };
    state.profile = { full_name: state.user.user_metadata.full_name, role, approved: true };
    state.view = role;
    state.modal = null;
    state.busy = false;
    render();
    showToast(`تم فتح واجهة ${roleName(role)} للتجربة.`);
  }

  function addToCart(productId) {
    const product = productFor(productId);
    if (!product) return;
    if (state.selectedMerchant && state.selectedMerchant !== product.merchant_id) {
      showToast('كل طلب من محل واحد. أكمل السلة الحالية أولاً.');
      return;
    }
    state.selectedMerchant = product.merchant_id;
    const existing = state.cart.find((line) => line.id === product.id);
    if (existing) existing.quantity += 1;
    else state.cart.push({ ...product, quantity: 1, merchantName: merchantFor(product.merchant_id)?.name || 'محل' });
    render();
    showToast(`تمت إضافة ${product.name} إلى السلة.`);
  }

  function changeCart(productId, delta) {
    const line = state.cart.find((item) => item.id === productId);
    if (!line) return;
    line.quantity += delta;
    if (line.quantity <= 0) state.cart = state.cart.filter((item) => item.id !== productId);
    if (!state.cart.length) state.selectedMerchant = null;
    render();
    if (state.modal === 'cart') state.modal = 'cart';
  }

  async function getLocation() {
    if (!navigator.geolocation) return showToast('المتصفح لا يدعم تحديد الموقع. استخدم وصف العنوان.');
    showToast('جارٍ تحديد موقعك...');
    navigator.geolocation.getCurrentPosition((position) => {
      state.location = { lat: position.coords.latitude, lng: position.coords.longitude };
      render();
      showToast('تم حفظ موقعك لمساعدة المندوب.');
    }, () => showToast('لم نتمكن من تحديد الموقع. اكتب العنوان بالوصف.'));
  }

  async function openTracking(orderId) {
    state.trackingOrder = state.orders.find((order) => String(order.id) === String(orderId)) || state.orders[0];
    state.trackingHistory = [];
    state.modal = 'tracking';
    render();
    if (client && !isDemo() && state.trackingOrder?.id) {
      const { data } = await client.from('order_status_history').select('*').eq('order_id', state.trackingOrder.id).order('changed_at', { ascending: true });
      state.trackingHistory = data || [];
      render();
    }
  }

  async function submitOrder() {
    const address = document.getElementById('address-input')?.value.trim();
    const phone = document.getElementById('checkout-phone')?.value.trim();
    const payment = document.querySelector('input[name="payment"]:checked')?.value || 'paid_to_store';
    const paymentRef = document.getElementById('payment-ref')?.value.trim() || null;
    if (!address) return showToast('اكتب عنوان التوصيل بالتفصيل.');
    if (!phone) return showToast('اكتب رقمًا للتواصل عند الوصول.');
    const payload = {
      merchant_id: state.selectedMerchant,
      items: state.cart.map((line) => ({ product_id: line.id, name: line.name, quantity: line.quantity, unit_price: line.price })),
      subtotal: cartSubtotal(),
      delivery_fee: cartFee(),
      total: cartTotal(),
      payment_method: payment,
      payment_reference: paymentRef,
      address_text: address,
      contact_phone: normalizePhone(phone),
      pickup_address_text: selectedMerchant()?.address || selectedMerchant()?.name || 'المحل المحدد',
      latitude: state.location?.lat || null,
      longitude: state.location?.lng || null,
      status: 'pending'
    };
    if (isDemo() || !client) {
      state.orders.unshift({ id: `MW-${1043 + state.orders.length}`, merchant: selectedMerchant()?.name || 'محل مشاوير', customer: state.profile?.full_name || 'عميل مشاوير', status: 'pending', statusText: orderLabels.pending, total: payload.total, address, payment: payment, created_at: 'الآن' });
      finishOrder();
      showToast('تم تسجيل الطلب، وستتابعه الإدارة حتى تعيين المندوب.');
      return;
    }
    const { data, error } = await client.from('orders').insert({ ...payload, user_id: state.user.id, payment_status: payment === 'paid_to_store' ? 'not_required' : 'pending' }).select().single();
    if (error) return showToast(error.message || 'تعذر تسجيل الطلب.');
    state.orders.unshift(mapOrder(data));
    finishOrder();
    showToast('تم تسجيل الطلب بنجاح.');
  }

  function finishOrder() {
    state.cart = [];
    state.selectedMerchant = null;
    state.location = null;
    state.checkoutAddress = '';
    state.modal = null;
    render();
  }

  async function advanceOrder(orderId, requestedStatus = null) {
    const order = state.orders.find((item) => String(item.id) === String(orderId)) || state.orders[0];
    if (!order) return;
    const nextSteps = { assigned: 'driver_accepted', driver_accepted: 'heading_to_pickup', heading_to_pickup: 'arrived_pickup', arrived_pickup: 'picked_up', picked_up: 'delivering', delivering: 'arrived_destination', arrived_destination: 'delivered' };
    const nextStatus = requestedStatus || nextSteps[canonicalStatus(order)];
    if (!nextStatus) return showToast('لا توجد خطوة تالية لهذا الطلب.');
    if (client && !isDemo() && order.id) {
      const { data, error } = await client.rpc('advance_order', { order_id_value: order.id, next_status_value: nextStatus });
      if (error) return showToast(error.message || 'تعذر تحديث حالة الطلب.');
      Object.assign(order, mapOrder(Array.isArray(data) ? data[0] : data));
    } else {
      order.status = nextStatus;
      order.statusText = orderLabels[nextStatus] || nextStatus;
    }
    render();
    showToast(`تم تحديث الحالة إلى: ${orderLabels[nextStatus] || nextStatus}`);
  }

  function setRoleView(role) {
    if (!state.user?.demo) return showToast('حسابك يفتح الواجهة الخاصة بدوره فقط.');
    state.profile.role = role;
    state.user.user_metadata.role = role;
    state.view = role;
    render();
  }

  async function logout() {
    if (client && !isDemo()) await client.auth.signOut();
    if (client && state.liveChannel) { await client.removeChannel(state.liveChannel); state.liveChannel = null; }
    if (state.refreshTimer) { window.clearInterval(state.refreshTimer); state.refreshTimer = null; }
    state.user = null;
    state.profile = null;
    state.view = 'customer';
    state.modal = null;
    render();
    showToast('تم تسجيل الخروج.');
  }

  function handleClick(event) {
    const target = event.target.closest('[data-action]');
    if (!target) return;
    const action = target.dataset.action;
    if (action === 'backdrop' && event.target !== target) return;
    if (action === 'open-auth') { state.modal = 'auth'; state.authMode = target.dataset.mode || 'login'; state.authRole = loginRoles.includes(target.dataset.role) ? target.dataset.role : 'customer'; render(); return; }
    if (action === 'auth-mode') { state.modal = 'auth'; state.authMode = target.dataset.mode; if (state.authMode === 'signup' && state.authRole === 'admin') state.authRole = 'customer'; render(); return; }
    if (action === 'auth-role') { state.authRole = target.dataset.role; render(); return; }
    if (action === 'close-modal' || action === 'backdrop') { state.modal = null; render(); return; }
    if (action === 'toggle-password') { const input = target.closest('.password-row')?.querySelector('input'); if (input) input.type = input.type === 'password' ? 'text' : 'password'; return; }
    if (action === 'go-home') { event.preventDefault(); state.selectedMerchant = null; state.selectedCategory = 'الكل'; render(); return; }
    if (action === 'choose-merchant') { state.selectedMerchant = target.dataset.merchant; state.selectedCategory = 'الكل'; render(); document.getElementById('products')?.scrollIntoView({ behavior: 'smooth' }); return; }
    if (action === 'clear-merchant') { state.selectedMerchant = null; render(); return; }
    if (action === 'category') { state.selectedCategory = target.dataset.category; if (state.selectedCategory !== 'الكل') state.selectedMerchant = null; render(); return; }
    if (action === 'scroll-products') { document.getElementById('products')?.scrollIntoView({ behavior: 'smooth' }); return; }
    if (action === 'add-cart') { addToCart(target.dataset.product); return; }
    if (action === 'open-cart') { state.modal = 'cart'; render(); return; }
    if (action === 'open-orders') { document.getElementById('orders')?.scrollIntoView({ behavior: 'smooth' }); return; }
    if (action === 'track-order') { openTracking(target.dataset.orderId); return; }
    if (action === 'cart-inc') { changeCart(target.dataset.product, 1); return; }
    if (action === 'cart-dec') { changeCart(target.dataset.product, -1); return; }
    if (action === 'locate') { getLocation(); return; }
    if (action === 'use-account-phone') {
      const phone = state.profile?.phone || state.user?.user_metadata?.phone || state.user?.phone || '';
      const input = document.getElementById('checkout-phone');
      if (phone && input) {
        input.value = phone;
        showToast('تم استخدام رقم الهاتف المحفوظ في الحساب.');
      } else showToast('لا يوجد رقم محفوظ في الحساب. اكتب رقم التواصل يدويًا.');
      return;
    }
    if (action === 'submit-order') { submitOrder(); return; }
    if (action === 'logout') { logout(); return; }
    if (action === 'switch-demo') { setRoleView(target.dataset.view); return; }
    if (action === 'dashboard-tab') { state.adminTab = target.dataset.tab; render(); return; }
    if (action === 'toggle-online') { state.courierOnline = !state.courierOnline; render(); showToast(state.courierOnline ? 'أصبحت متاحًا لاستقبال الطلبات.' : 'تم إيقاف استقبال الطلبات.'); return; }
    if (action === 'advance-order') { advanceOrder(target.dataset.orderId, target.dataset.nextStatus || null); return; }
    if (action === 'reject-order') { advanceOrder(target.dataset.orderId, 'rejected'); return; }
    if (action === 'cancel-order') { advanceOrder(target.dataset.orderId, 'cancelled'); return; }
    if (action === 'approve-courier') {
      if (client && !isDemo() && target.dataset.courierId) {
        client.from('profiles').update({ approved: true }).eq('id', target.dataset.courierId).then(({ error }) => {
          if (error) return showToast('تعذر اعتماد المندوب.');
          loadProfile(state.user).then(() => { render(); showToast(`تم اعتماد ${target.dataset.courier}.`); });
        });
      } else showToast(`تم فتح ملف ${target.dataset.courier} للمراجعة.`);
      return;
    }
    if (action === 'show-notice') { showToast(target.dataset.message || state.notifications[0]?.body || 'لا توجد إشعارات جديدة.'); return; }
  }

  function handleSubmit(event) {
    if (event.target.id !== 'auth-form') return;
    event.preventDefault();
    submitAuth(event.target);
  }

  function brand() {
    return `<a class="brand" href="#" data-action="go-home"><img class="brand-mark" src="icon.svg" alt="" /><span>مشاوير<small>دائمًا سابقين بخطوة</small></span></a>`;
  }

  function landingView() {
    const entries = [
      ['customer', 'تطبيق العميل', 'اطلب من محلات قريتك وتابع مشوارك حتى بابك.', 'ابدأ كعميل', 'signup'],
      ['courier', 'تطبيق المندوب', 'استقبل الطلبات، ابدأ الطريق، وسلّم الشحنة بسهولة.', 'دخول المندوب', 'login'],
      ['admin', 'لوحة تحكم المكتب', 'تابع الطلبات والعملاء والمندوبين والأسعار من مكان واحد.', 'دخول الإدارة', 'login']
    ];
    return `<div class="landing-view"><header class="landing-header container">${brand()}<button class="ghost-button" data-action="open-auth" data-mode="login" data-role="customer">تسجيل الدخول</button></header><main class="landing-main container"><section class="landing-hero"><div class="landing-copy"><span class="landing-kicker">مشاوير · توصيل محلي</span><h1>من قلب قريتك،<br /><em>يوصلك أسرع.</em></h1><p>مطاعم، بقالة، صيدلية وطرود. مشوارك واضح من لحظة الطلب حتى التسليم.</p><div class="landing-actions"><button class="primary-button" data-action="open-auth" data-mode="signup" data-role="customer">إنشاء حساب عميل</button><button class="light-button" data-action="open-auth" data-mode="login" data-role="courier">أنا مندوب</button></div></div><div class="landing-mark"><div class="mark-swoosh"></div><img src="icon.svg" alt="مشاوير" /><strong>مشاوير</strong><span>دائمًا سابقين بخطوة</span></div></section><section class="entry-section"><div class="section-heading"><div><span class="section-kicker">اختار طريقك</span><h2>كل دور له تجربته</h2></div><span class="section-hint">دخول آمن حسب نوع الحساب</span></div><div class="entry-grid">${entries.map(([role, title, desc, label, mode]) => `<article class="entry-card entry-${role}"><div class="entry-icon">${role === 'customer' ? '⌂' : role === 'courier' ? '➤' : '▦'}</div><h3>${title}</h3><p>${desc}</p><button class="entry-button" data-action="open-auth" data-mode="${mode}" data-role="${role}">${label} <span>←</span></button></article>`).join('')}</div></section><section class="trust-strip"><span>✓ أسعار واضحة</span><span>✓ متابعة مباشرة</span><span>✓ محلات قريبة منك</span><span>✓ دفع يناسبك</span></section></main></div>`;
  }

  function customerView() {
    const name = state.profile?.full_name || state.user?.user_metadata?.full_name || 'يا صديقي';
    const filtered = products.filter((product) => (state.selectedCategory === 'الكل' || product.category === state.selectedCategory) && (!state.selectedMerchant || product.merchant_id === state.selectedMerchant));
    const latest = state.orders.slice(0, 2);
    return `<div class="customer-app"><header class="app-header container"><div class="header-location"><span class="location-pin">●</span><div><small>توصيل إلى</small><strong>عنوانك الحالي</strong></div></div><div class="header-actions"><button class="icon-button" data-action="show-notice" data-message="لا توجد إشعارات جديدة." title="الإشعارات">♧</button><button class="avatar" data-action="logout" title="تسجيل الخروج">${escapeHTML(initials(name))}</button></div></header><main class="customer-main container"><section class="customer-welcome"><div><span class="section-kicker">أهلاً ${escapeHTML(name.split(' ')[0])}</span><h1>جاهز لمشوار<br /><em>يوصلك أسرع.</em></h1><p>اختار طلبك، وإحنا نكمل الطريق.</p></div><div class="welcome-scooter">➤</div></section><section class="service-grid">${[['مطاعم','🍽'],['بقالة','🛒'],['صيدلية','◉'],['طرود','▣']].map(([label,icon]) => `<button class="service-tile" data-action="category" data-category="${label}"><span>${icon}</span><b>${label}</b></button>`).join('')}</section><section class="promo-strip app-promo"><div><b>مشوارك دايمًا سابقين بخطوة</b><span>تابع كل مرحلة من الطلب حتى بابك.</span></div><strong>★</strong></section><section class="app-section"><div class="section-heading"><div><span class="section-kicker">اختيارات قريبة</span><h2>محلات قريتك</h2></div><button class="link-button" data-action="category" data-category="الكل">عرض الكل ←</button></div><div class="merchant-grid">${merchants.map(merchantCard).join('')}</div></section><section id="products" class="app-section"><div class="section-heading"><div><span class="section-kicker">اطلب اللي تحتاجه</span><h2>${state.selectedMerchant ? escapeHTML(selectedMerchant().name) : 'الأكثر طلبًا'}</h2></div><button class="link-button" data-action="open-cart">السلة (${state.cart.reduce((s, item) => s + item.quantity, 0)})</button></div><div class="product-grid">${filtered.map(productCard).join('') || '<div class="empty-state">لا توجد أصناف في هذا القسم بعد.</div>'}</div></section><section id="orders" class="app-section"><div class="section-heading"><div><span class="section-kicker">لا تضيع مشوارك</span><h2>طلباتك الأخيرة</h2></div><button class="link-button" data-action="open-orders">كل الطلبات ←</button></div><div class="order-list">${latest.length ? latest.map((order) => `<button class="order-card" data-action="track-order" data-order-id="${escapeHTML(order.id || '')}"><span class="order-status-dot ${statusClass(order.statusText || 'جديد')}"></span><span class="order-card-main"><b>${escapeHTML(order.merchant || 'طلب مشاوير')}</b><small>${escapeHTML(order.address || 'العنوان غير محدد')} · ${escapeHTML(order.created_at || 'الآن')}</small></span><span class="order-card-side">${statusBadge(order.statusText || 'جديد')}<strong>${money(order.total)}</strong></span><span class="order-arrow">‹</span></button>`).join('') : '<div class="empty-state">أول مشوار مستنيك.</div>'}</div></section></main><nav class="app-bottom-nav"><button class="active" data-action="go-home"><b>⌂</b><span>الرئيسية</span></button><button data-action="open-orders"><b>◷</b><span>طلباتي</span></button><button data-action="open-cart"><b>🛒</b><span>السلة</span></button><button data-action="show-notice" data-message="الملف الشخصي جاهز."><b>♙</b><span>حسابي</span></button></nav></div>`;
  }

  function dashboardView() {
    const admin = currentRole() === 'admin';
    return `<div class="role-dashboard ${admin ? 'admin-dashboard' : 'courier-dashboard'}"><header class="app-header container"><div>${brand()}</div><div class="header-actions"><span class="role-pill">${admin ? 'لوحة المكتب' : 'تطبيق المندوب'}</span><button class="avatar" data-action="logout">↪</button></div></header><main class="dashboard-main container">${dashboardTop()}${admin ? adminView() : courierView()}</main><nav class="app-bottom-nav dashboard-bottom">${admin ? '<button class="active" data-action="dashboard-tab" data-tab="overview"><b>▦</b><span>الرئيسية</span></button><button data-action="dashboard-tab" data-tab="orders"><b>▤</b><span>الطلبات</span></button><button data-action="dashboard-tab" data-tab="couriers"><b>♙</b><span>المندوبون</span></button><button data-action="dashboard-tab" data-tab="shops"><b>⌁</b><span>الأسعار</span></button>' : '<button class="active" data-action="dashboard-tab" data-tab="overview"><b>⌂</b><span>الرئيسية</span></button><button data-action="dashboard-tab" data-tab="orders"><b>▤</b><span>طلباتي</span></button><button data-action="dashboard-tab" data-tab="earnings"><b>ج.م</b><span>حسابي</span></button>'}</nav></div>`;
  }

  function dashboardTop() {
    const admin = currentRole() === 'admin';
    const name = state.profile?.full_name || state.user?.user_metadata?.full_name || roleName(currentRole());
    return `<section class="dashboard-heading"><div><span class="section-kicker">${admin ? 'صباح الخير' : 'جاهز للمشوار؟'}</span><h1>${admin ? 'لوحة تحكم مشاوير' : `أهلاً ${escapeHTML(name.split(' ')[0])}`}</h1><p>${admin ? 'كل حركة الطلبات والمندوبين أمامك.' : 'استقبل طلبات جديدة وابقَ سابقًا بخطوة.'}</p></div><span class="online-badge ${state.courierOnline ? 'online' : ''}">${admin ? 'متصل الآن' : state.courierOnline ? 'متاح للعمل' : 'غير متاح'}</span></section>`;
  }

  function courierView() {
    if (!isDemo() && state.profile?.approved === false) return `<section class="pending-courier"><div class="pending-icon">➤</div><span class="section-kicker">تم استلام طلب التسجيل</span><h2>حسابك قيد مراجعة الإدارة</h2><p>بعد الموافقة ستظهر لك الطلبات الجديدة هنا، ويمكنك بدء المشوار وتحديث حالته.</p></section>`;
    const assigned = state.orders.slice(0, 4);
    const earnings = assigned.reduce((sum, order) => sum + Number(order.delivery_fee || 0), 0);
    return `<section class="courier-summary"><div><span>حسابي اليوم</span><strong>${money(earnings)}</strong><small>${assigned.length} مشاوير مسندة إليك</small></div><button class="toggle ${state.courierOnline ? 'on' : ''}" data-action="toggle-online"><i></i></button></section><section class="route-card"><div class="panel-title"><div><span class="section-kicker">المشوار الحالي</span><h2>${assigned[0] ? 'طريقك إلى العميل' : 'لا توجد مشاوير الآن'}</h2></div><span class="route-time">${assigned[0] ? '12 دقيقة' : 'متاح'}</span></div><div class="route-map"><span class="map-road road-one"></span><span class="map-road road-two"></span><span class="map-road road-three"></span><span class="map-point start"></span><span class="map-point finish"></span><span class="map-scooter">➤</span></div>${assigned[0] ? `<div class="route-meta"><span>📍 ${escapeHTML(assigned[0].address || 'عنوان العميل')}</span><b>${money(assigned[0].total)}</b></div><button class="primary-button wide-button" data-action="track-order" data-order-id="${escapeHTML(assigned[0].id || '')}">عرض تفاصيل الطلب</button>` : '<div class="empty-state">ستظهر الطلبات الجديدة هنا.</div>'}</section><section class="app-section"><div class="section-heading"><div><span class="section-kicker">طلبات اليوم</span><h2>المشاوير المسندة</h2></div><span class="count-pill">${assigned.length}</span></div><div class="courier-order-list">${assigned.length ? assigned.map((order) => `<article class="courier-card"><div class="courier-card-top"><span class="order-number">#${escapeHTML(String(order.id || '').slice(-4) || '1258')}</span>${statusBadge(order.statusText || 'جديد')}</div><h3>${escapeHTML(order.merchant || 'طلب مشاوير')}</h3><p>📍 ${escapeHTML(order.address || 'العنوان غير محدد')}</p><div class="courier-card-bottom"><strong>${money(order.total)}</strong><button class="primary-button small-button" data-action="advance-order" data-order-id="${escapeHTML(order.id || '')}">تحديث الحالة</button></div></article>`).join('') : '<div class="empty-state">لا توجد طلبات مسندة إليك.</div>'}</div></section>`;
  }

  function adminView() {
    const rows = state.orders.slice(0, 6);
    const couriers = isDemo() ? demoCouriers : state.couriers;
    const revenue = state.orders.reduce((sum, order) => sum + Number(order.delivery_fee || 0), 0);
    return `<section class="dashboard-kpis"><div><span>طلبات اليوم</span><strong>${state.orders.length}</strong><small>+12% عن أمس</small></div><div><span>تم التسليم</span><strong>${state.orders.filter((o) => o.statusText === 'تم التسليم').length}</strong><small>بنجاح</small></div><div><span>قيد التنفيذ</span><strong>${state.orders.filter((o) => o.statusText !== 'تم التسليم').length}</strong><small>تحتاج متابعة</small></div><div><span>إجمالي التوصيل</span><strong>${money(revenue)}</strong><small>هذا الشهر</small></div></section><section class="admin-panel"><div class="panel-title"><div><span class="section-kicker">الحركة الآن</span><h2>إدارة الطلبات</h2></div><button class="link-button" data-action="show-notice" data-message="إضافة طلب يدوي ستكون متاحة قريبًا.">+ طلب جديد</button></div><div class="admin-order-list">${rows.length ? rows.map((order) => `<button class="admin-order-row" data-action="track-order" data-order-id="${escapeHTML(order.id || '')}"><span class="order-number">#${escapeHTML(String(order.id || '').slice(-4) || '1258')}</span><span><b>${escapeHTML(order.merchant || 'طلب مشاوير')}</b><small>${escapeHTML(order.customer || 'عميل')} · ${escapeHTML(order.address || 'العنوان')}</small></span>${statusBadge(order.statusText || 'جديد')}<strong>${money(order.total)}</strong></button>`).join('') : '<div class="empty-state">لا توجد طلبات حقيقية بعد.</div>'}</div></section><section class="admin-panel"><div class="panel-title"><div><span class="section-kicker">فريق التوصيل</span><h2>المندوبون</h2></div><span class="count-pill">${couriers.length}</span></div><div class="people-list">${couriers.slice(0, 5).map((courier) => `<div class="person-row"><span class="person-avatar">${escapeHTML(initials(courier.full_name || courier.name))}</span><span><b>${escapeHTML(courier.full_name || courier.name || 'مندوب')}</b><small>${escapeHTML(courier.phone || '')}</small></span><span class="person-state ${courier.approved === false ? 'pending' : ''}">${courier.approved === false ? 'بانتظار الموافقة' : 'متاح'}</span>${courier.approved === false ? `<button class="link-button" data-action="approve-courier" data-courier-id="${escapeHTML(courier.id || '')}" data-courier="${escapeHTML(courier.full_name || courier.name || 'مندوب')}">موافقة</button>` : ''}</div>`).join('') || '<div class="empty-state">لا يوجد مندوبون بعد.</div>'}</div></section>`;
  }

  function modalView() {
    return `<div class="modal-backdrop" data-action="backdrop"><section class="modal ${state.modal === 'cart' ? 'modal-wide' : ''} ${state.modal === 'tracking' ? 'tracking-modal' : ''}" role="dialog" aria-modal="true">${state.modal === 'auth' ? authModal() : state.modal === 'cart' ? cartModal() : trackingModal()}</section></div>`;
  }

  function trackingModal() {
    const order = state.trackingOrder || state.orders[0] || { id: 'MW-1258', merchant: 'طلب مشاوير', total: 80, address: 'العنوان غير محدد', statusText: 'جديد' };
    const stages = ['تم استلام الطلب', 'قيد التجهيز', 'في الطريق', 'تم التسليم'];
    const current = Math.max(0, stages.indexOf(order.statusText));
    return `<div class="modal-head"><div><span class="section-kicker">تتبع الطلب</span><h2>#${escapeHTML(String(order.id || '').slice(-4) || '1258')}</h2><p>${escapeHTML(order.merchant || 'طلب مشاوير')} · ${money(order.total)}</p></div><button class="close-button" data-action="close-modal">×</button></div><div class="modal-body tracking-body"><div class="tracking-map"><span class="map-road road-one"></span><span class="map-road road-two"></span><span class="map-point start"></span><span class="map-point finish"></span><span class="map-scooter">➤</span></div><div class="tracking-address"><span>📍</span><div><b>التوصيل إلى</b><small>${escapeHTML(order.address || 'العنوان غير محدد')}</small></div></div><div class="timeline">${stages.map((stage, index) => `<div class="timeline-step ${index <= current ? 'done' : ''} ${index === current ? 'current' : ''}"><span></span><div><b>${stage}</b><small>${index <= current ? (index === current ? 'جاري الآن' : 'تم') : 'قريبًا'}</small></div></div>`).join('')}</div><button class="primary-button wide-button" data-action="close-modal">تم</button></div>`;
  }

  function cartModal() {
    const subtotal = cartSubtotal();
    const accountPhone = state.profile?.phone || state.user?.user_metadata?.phone || state.user?.phone || '';
    if (!state.cart.length) return `<div class="modal-head"><div><h2>السلة فارغة</h2><p>أضف أصنافًا من المحلات أولًا.</p></div><button class="close-button" data-action="close-modal">×</button></div><div class="modal-body"><div class="empty-state">اختار طلبك، وإحنا نكمل الطريق.</div></div>`;
    return `<div class="modal-head"><div><span class="section-kicker">مشوار جديد</span><h2>راجع طلبك</h2><p>${selectedMerchant() ? escapeHTML(selectedMerchant().name) : 'أضف أصنافًا من محل واحد لكل طلب.'}</p></div><button class="close-button" data-action="close-modal">×</button></div><div class="modal-body checkout-body"><div class="cart-lines">${state.cart.map(cartLine).join('')}</div><div class="form-grid checkout-fields"><div class="field"><label>عنوان التوصيل بالوصف</label><textarea name="address" id="address-input" placeholder="اسم الشارع، علامة مميزة، الدور...">${escapeHTML(state.checkoutAddress || '')}</textarea></div><div class="map-box"><span>📍 ${state.location ? 'تم تحديد موقعك على الخريطة' : 'أضف موقعك لمساعدة المندوب'}</span><button type="button" class="ghost-button small-button" data-action="locate">${state.location ? 'تحديث الموقع' : 'استخدم موقعي'}</button></div><div class="field"><label>رقم التواصل عند الوصول</label><div class="contact-phone-row"><input id="checkout-phone" name="checkout_phone" inputmode="tel" value="${escapeHTML(accountPhone)}" placeholder="01xxxxxxxxx" /><button type="button" class="ghost-button small-button" data-action="use-account-phone">استخدم رقم الحساب</button></div><span class="field-hint">يمكنك تغييره لأي رقم آخر قبل تأكيد الطلب.</span></div><div class="field"><label>طريقة الدفع أو التسوية</label><div class="payment-list"><label class="payment-option"><input type="radio" name="payment" value="paid_to_store" checked /><span>دفعت للمحل، والمطلوب توصيل فقط</span></label><label class="payment-option"><input type="radio" name="payment" value="vodafone_cash" /><span>Vodafone Cash</span></label><label class="payment-option"><input type="radio" name="payment" value="instapay" /><span>InstaPay</span></label><label class="payment-option"><input type="radio" name="payment" value="cash" /><span>الدفع عند الاستلام</span></label></div></div><div class="field"><label>رقم العملية، إن وجد</label><input id="payment-ref" placeholder="اختياري" /></div><div class="order-total"><span>الإجمالي التقريبي</span><span>${money(subtotal)} + ${money(cartFee())} توصيل = ${money(cartTotal())}</span></div><button class="primary-button wide-button" data-action="submit-order">تأكيد الطلب · ${money(cartTotal())}</button></div></div>`;
  }

  function orderStatusOptions(selected) {
    return Object.entries(orderLabels).map(([value, label]) => `<option value="${value}" ${value === selected ? 'selected' : ''}>${label}</option>`).join('');
  }

  function courierActionButtons(order) {
    const status = canonicalStatus(order);
    if (status === 'assigned') return `<button class="primary-button small-button" data-action="advance-order" data-next-status="driver_accepted" data-order-id="${escapeHTML(order.id || '')}">قبول الطلب</button><button class="ghost-button small-button" data-action="reject-order" data-order-id="${escapeHTML(order.id || '')}">رفض</button>`;
    const next = { driver_accepted: ['heading_to_pickup', 'اتجه للاستلام'], heading_to_pickup: ['arrived_pickup', 'وصلت للاستلام'], arrived_pickup: ['picked_up', 'استلمت الطلب'], picked_up: ['delivering', 'ابدأ التوصيل'], delivering: ['arrived_destination', 'وصلت للعميل'], arrived_destination: ['delivered', 'تأكيد التسليم'] }[status];
    return next ? `<button class="primary-button small-button" data-action="advance-order" data-next-status="${next[0]}" data-order-id="${escapeHTML(order.id || '')}">${next[1]}</button>` : '';
  }

  function courierView() {
    if (!isDemo() && state.profile?.approved === false) return `<section class="pending-courier"><div class="pending-icon">➤</div><span class="section-kicker">تم استلام طلب التسجيل</span><h2>حسابك قيد مراجعة الإدارة</h2><p>بعد الموافقة ستظهر لك الطلبات الجديدة هنا، ويمكنك بدء المشوار وتحديث حالته.</p></section>`;
    const assigned = state.orders.filter((order) => !['delivered', 'cancelled', 'failed', 'rejected'].includes(canonicalStatus(order))).slice(0, 6);
    const earnings = assigned.reduce((sum, order) => sum + Number(order.delivery_fee || 0), 0);
    return `<section class="courier-summary"><div><span>حسابي اليوم</span><strong>${money(earnings)}</strong><small>${assigned.length} مشاوير مسندة إليك</small></div><button class="toggle ${state.courierOnline ? 'on' : ''}" data-action="toggle-online"><i></i></button></section><section class="route-card"><div class="panel-title"><div><span class="section-kicker">المشوار الحالي</span><h2>${assigned[0] ? 'طريقك إلى العميل' : 'لا توجد مشاوير الآن'}</h2></div><span class="route-time">${assigned[0] ? 'متابعة مباشرة' : 'متاح'}</span></div><div class="route-map"><span class="map-road road-one"></span><span class="map-road road-two"></span><span class="map-road road-three"></span><span class="map-point start"></span><span class="map-point finish"></span><span class="map-scooter">➤</span></div>${assigned[0] ? `<div class="route-meta"><span>📍 ${escapeHTML(assigned[0].address || 'عنوان العميل')}</span><b>${money(assigned[0].total)}</b></div>` : '<div class="empty-state">ستظهر الطلبات الجديدة هنا بعد إسنادها إليك.</div>'}</section><section class="app-section"><div class="section-heading"><div><span class="section-kicker">دورة التنفيذ</span><h2>طلباتك الحالية</h2></div><span class="count-pill">${assigned.length}</span></div><div class="courier-order-list">${assigned.length ? assigned.map((order) => `<article class="courier-card"><div class="courier-card-top"><span class="order-number">#${escapeHTML(String(order.id || '').slice(-4) || '1258')}</span>${statusBadge(order.statusText || order.status)}</div><h3>${escapeHTML(order.merchant || 'طلب مشاوير')}</h3><p>📍 ${escapeHTML(order.address || 'العنوان غير محدد')}</p><div class="courier-card-bottom"><strong>${money(order.total)}</strong><div class="order-actions">${courierActionButtons(order)}</div></div></article>`).join('') : '<div class="empty-state">لا توجد طلبات مسندة إليك.</div>'}</div></section>`;
  }

  function adminView() {
    const rows = state.orders.slice(0, 10);
    const couriers = isDemo() ? demoCouriers : state.couriers;
    const revenue = state.orders.reduce((sum, order) => sum + Number(order.delivery_fee || 0), 0);
    const approvedCouriers = couriers.filter((courier) => courier.approved !== false);
    const courierOptions = (order) => `<select class="assign-select" data-action="assign-order" data-order-id="${escapeHTML(order.id || '')}" aria-label="توجيه الطلب"><option value="">غير موجّه</option>${approvedCouriers.map((courier) => `<option value="${escapeHTML(courier.id || '')}" ${String(order.courier_id || '') === String(courier.id || '') ? 'selected' : ''}>${escapeHTML(courier.full_name || courier.name || 'مندوب')}</option>`).join('')}</select>`;
    return `<section class="dashboard-kpis"><div><span>كل الطلبات</span><strong>${state.orders.length}</strong><small>متزامنة مع النظام</small></div><div><span>بانتظار مندوب</span><strong>${state.orders.filter((o) => ['pending', 'confirmed', 'searching_driver'].includes(canonicalStatus(o))).length}</strong><small>تحتاج إسنادًا</small></div><div><span>قيد التنفيذ</span><strong>${state.orders.filter((o) => !['delivered', 'cancelled', 'failed'].includes(canonicalStatus(o))).length}</strong><small>متابعة مستمرة</small></div><div><span>إجمالي التوصيل</span><strong>${money(revenue)}</strong><small>هذا الشهر</small></div></section><section class="admin-panel"><div class="panel-title"><div><span class="section-kicker">المسار المركزي</span><h2>إدارة وتوجيه الطلبات</h2></div><span class="count-pill">${rows.length}</span></div><p class="panel-help">التعيين وتغيير الحالة يتمان بصلاحية الإدارة، ثم يصلان تلقائيًا للعميل والمندوب.</p><div class="admin-order-list">${rows.length ? rows.map((order) => `<div class="admin-order-row"><span class="order-number">#${escapeHTML(String(order.id || '').slice(-4) || '1258')}</span><span><b>${escapeHTML(order.merchant || 'طلب مشاوير')}</b><small>${escapeHTML(order.customer || 'العميل')} · ${escapeHTML(order.address || 'العنوان')}</small></span><select class="assign-select" data-action="change-order-status" data-order-id="${escapeHTML(order.id || '')}" aria-label="حالة الطلب">${orderStatusOptions(canonicalStatus(order))}</select><div class="admin-assignment">${courierOptions(order)}<button class="link-button" data-action="track-order" data-order-id="${escapeHTML(order.id || '')}">تفاصيل</button></div></div>`).join('') : '<div class="empty-state">لا توجد طلبات حقيقية بعد.</div>'}</div></section><section class="admin-panel"><div class="panel-title"><div><span class="section-kicker">فريق التوصيل</span><h2>المندوبون</h2></div><span class="count-pill">${couriers.length}</span></div><div class="people-list">${couriers.slice(0, 8).map((courier) => `<div class="person-row"><span class="person-avatar">${escapeHTML(initials(courier.full_name || courier.name))}</span><span><b>${escapeHTML(courier.full_name || courier.name || 'مندوب')}</b><small>${escapeHTML(courier.phone || '')}</small></span><span class="person-state ${courier.approved === false ? 'pending' : ''}">${courier.approved === false ? 'بانتظار الموافقة' : 'معتمد'}</span>${courier.approved === false ? `<button class="ghost-button small-button" data-action="approve-courier" data-courier-id="${escapeHTML(courier.id || '')}" data-courier="${escapeHTML(courier.full_name || courier.name || 'المندوب')}">موافقة</button>` : ''}</div>`).join('') || '<div class="empty-state">لا يوجد مندوبون مسجلون بعد.</div>'}</div></section>`;
  }

  function trackingModal() {
    const order = state.trackingOrder || state.orders[0] || { id: 'MW-1258', merchant: 'طلب مشاوير', total: 80, address: 'العنوان غير محدد', status: 'pending' };
    const stages = ['pending', 'confirmed', 'searching_driver', 'assigned', 'driver_accepted', 'heading_to_pickup', 'arrived_pickup', 'picked_up', 'delivering', 'arrived_destination', 'delivered'];
    const current = Math.max(0, stages.indexOf(canonicalStatus(order)));
    return `<div class="modal-head"><div><span class="section-kicker">تتبع الطلب</span><h2>#${escapeHTML(String(order.id || '').slice(-4) || '1258')}</h2><p>${escapeHTML(order.merchant || 'طلب مشاوير')} · ${money(order.total)}</p></div><button class="close-button" data-action="close-modal">×</button></div><div class="modal-body tracking-body"><div class="tracking-map"><span class="map-road road-one"></span><span class="map-road road-two"></span><span class="map-point start"></span><span class="map-point finish"></span><span class="map-scooter">➤</span></div><div class="tracking-address"><span>📍</span><div><b>التوصيل إلى</b><small>${escapeHTML(order.address || 'العنوان غير محدد')}</small></div></div><div class="timeline">${stages.map((stage, index) => `<div class="timeline-step ${index <= current ? 'done' : ''} ${index === current ? 'current' : ''}"><span></span><div><b>${orderLabels[stage]}</b><small>${index <= current ? (index === current ? 'جاري الآن' : 'تم') : 'قريبًا'}</small></div></div>`).join('')}</div><button class="primary-button wide-button" data-action="close-modal">تم</button></div>`;
  }

  function customerView() {
    const name = state.profile?.full_name || state.user?.user_metadata?.full_name || 'يا صديقي';
    const filtered = products.filter((product) => (state.selectedCategory === 'الكل' || product.category === state.selectedCategory) && (!state.selectedMerchant || product.merchant_id === state.selectedMerchant));
    const orders = state.orders.slice(0, 3);
    return `<div class="customer-app"><header class="app-header container"><div class="header-location"><span class="location-pin">●</span><div><small>توصيل إلى</small><strong>عنوانك الحالي</strong></div></div><div class="header-actions"><button class="icon-button" data-action="show-notice" data-message="${escapeHTML(state.notifications[0]?.body || 'لا توجد إشعارات جديدة.')}">♧${state.notifications.length ? `<sup>${state.notifications.length}</sup>` : ''}</button><button class="avatar" data-action="logout">${escapeHTML(initials(name))}</button></div></header><main class="customer-main container"><section class="customer-welcome"><div><span class="section-kicker">أهلاً ${escapeHTML(name.split(' ')[0])}</span><h1>جاهز لمشوار<br /><em>يوصلك أسرع.</em></h1><p>اختار طلبك، وإحنا نكمل الطريق.</p></div><div class="welcome-scooter">➤</div></section><section class="service-grid">${[['مطاعم','🍽'],['بقالة','🛒'],['صيدلية','◉'],['طرود','▣']].map(([label, icon]) => `<button class="service-tile" data-action="category" data-category="${label}"><span>${icon}</span><b>${label}</b></button>`).join('')}</section><section class="app-section"><div class="section-heading"><div><span class="section-kicker">آخر حركة</span><h2>طلباتك</h2></div><button class="link-button" data-action="show-notice" data-message="كل طلباتك محفوظة داخل حسابك.">السجل الكامل ←</button></div><div class="customer-order-list">${orders.length ? orders.map((order) => `<article class="customer-order-card"><div class="customer-order-head"><span class="order-number">#${escapeHTML(String(order.id || '').slice(-4) || '1258')}</span>${statusBadge(order.statusText || order.status)}</div><h3>${escapeHTML(order.merchant || 'طلب مشاوير')}</h3><p>📍 ${escapeHTML(order.address || 'العنوان غير محدد')}</p>${order.courier?.full_name ? `<small class="courier-contact">المندوب: ${escapeHTML(order.courier.full_name)}${order.courier.phone ? ` · ${escapeHTML(order.courier.phone)}` : ''}</small>` : ''}<div class="customer-order-actions"><strong>${money(order.total)}</strong><button class="primary-button small-button" data-action="track-order" data-order-id="${escapeHTML(order.id || '')}">تتبع الطلب</button>${canonicalStatus(order) === 'pending' ? `<button class="ghost-button small-button" data-action="cancel-order" data-order-id="${escapeHTML(order.id || '')}">إلغاء</button>` : ''}</div></article>`).join('') : '<div class="empty-state">لم تطلب شيئًا بعد. أول مشوار مستنيك.</div>'}</div></section><section class="app-section"><div class="section-heading"><div><span class="section-kicker">اختيارات قريبة</span><h2>محلات قريتك</h2></div><button class="link-button" data-action="category" data-category="الكل">عرض الكل ←</button></div><div class="merchant-grid">${merchants.map(merchantCard).join('')}</div></section><section id="products" class="app-section"><div class="section-heading"><div><span class="section-kicker">اطلب اللي تحتاجه</span><h2>${state.selectedMerchant ? escapeHTML(selectedMerchant().name) : 'الأكثر طلبًا'}</h2></div><button class="link-button" data-action="open-cart">السلة (${state.cart.reduce((sum, item) => sum + item.quantity, 0)})</button></div><div class="product-grid">${filtered.map(productCard).join('') || '<div class="empty-state">لا توجد أصناف في هذا القسم بعد.</div>'}</div></section></main></div>`;
  }

  async function boot() {
    document.addEventListener('click', handleClick);
    document.addEventListener('change', handleChange);
    document.addEventListener('submit', handleSubmit);
    app.innerHTML = '<div class="loading"><span class="loading-dot"></span></div>';
    if ('serviceWorker' in navigator) navigator.serviceWorker.register('sw.js').catch(() => {});
    if (client) {
      await loadCatalog();
      const { data } = await client.auth.getSession();
      if (data.session?.user) await completeAuth(data.session.user);
      client.auth.onAuthStateChange((_event, session) => {
        if (!session?.user && state.user && !state.user.demo) { state.user = null; state.profile = null; render(); }
      });
    }
    if (!state.user) render();
  }

  boot();
})();
